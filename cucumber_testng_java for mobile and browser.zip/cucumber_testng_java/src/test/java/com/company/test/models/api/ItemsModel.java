package com.company.test.models.api;

import lombok.Data;

import java.util.List;

@Data
public class ItemsModel {
    List<ItemModel> itemModels;
}
