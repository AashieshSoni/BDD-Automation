package com.company.test.models.database;

import lombok.Data;

@Data
public class UserRegModel {
    String logonId;
    String status;
}
